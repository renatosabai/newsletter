import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Protect the cron API route from unauthorized access
  if (request.nextUrl.pathname === "/api/cron") {
    // Check for cron job secret or admin authentication
    const cronSecret = request.headers.get("x-cron-secret")
    const isAuthorized =
      // Allow Vercel cron jobs
      request.headers.get("x-vercel-cron") === "true" ||
      // Allow requests with the correct secret
      cronSecret === process.env.CRON_SECRET ||
      // Allow local development
      process.env.NODE_ENV === "development"

    if (!isAuthorized) {
      return new NextResponse(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "content-type": "application/json" },
      })
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: "/api/cron",
}
