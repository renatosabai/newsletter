import { GoogleAuth } from "google-auth-library"

/**
 * Creates an authenticated Google client using Workload Identity Federation
 * This approach doesn't require service account keys
 */
export async function getGoogleAuthClient() {
  try {
    // Check if we're running on Vercel
    const isVercel = process.env.VERCEL === "1"

    if (isVercel) {
      // Use Workload Identity Federation when on Vercel
      const auth = new GoogleAuth({
        scopes: ["https://www.googleapis.com/auth/spreadsheets"],
        // These environment variables must be set in Vercel
        serviceAccountEmail: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
        workloadIdentityProvider: process.env.GOOGLE_WORKLOAD_IDENTITY_PROVIDER,
      })

      const client = await auth.getClient()
      return client
    } else {
      // For local development, use Application Default Credentials
      // You'll need to run `gcloud auth application-default login` locally
      const auth = new GoogleAuth({
        scopes: ["https://www.googleapis.com/auth/spreadsheets"],
      })

      const client = await auth.getClient()
      return client
    }
  } catch (error) {
    console.error("Error authenticating with Google:", error)
    throw new Error("Failed to authenticate with Google: " + error.message)
  }
}
