import { google } from "googleapis"
import { getGoogleAuthClient } from "./google-auth"
import type { Article } from "./scraper"

// Google Sheets configuration
const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID
const SHEET_NAME = "Articles"

/**
 * Adds processed articles to Google Sheet
 */
export async function addArticlesToSheet(articles: Array<Article & { summary: string; tags: string[] }>) {
  try {
    // Get authenticated client using Workload Identity Federation
    const authClient = await getGoogleAuthClient()
    const sheets = google.sheets({ version: "v4", auth: authClient })

    // Check if sheet exists, create if not
    await ensureSheetExists(sheets)

    // Get existing articles to avoid duplicates
    const existingArticles = await getExistingArticles(sheets)
    const existingUrls = new Set(existingArticles.map((row) => row[6])) // URL is in column G

    // Filter out articles that already exist in the sheet
    const newArticles = articles.filter((article) => !existingUrls.has(article.url))

    if (newArticles.length === 0) {
      console.log("No new articles to add to the sheet")
      return
    }

    // Prepare rows for the sheet
    const rows = newArticles.map((article, index) => [
      (existingArticles.length + index + 1).toString(), // Article #
      article.publishDate,
      article.title,
      article.summary,
      article.tags.join(", "),
      article.source,
      article.url,
    ])

    // Append rows to the sheet
    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: `${SHEET_NAME}!A:G`,
      valueInputOption: "USER_ENTERED",
      requestBody: {
        values: rows,
      },
    })

    console.log(`Added ${newArticles.length} new articles to the sheet`)
  } catch (error) {
    console.error("Error adding articles to Google Sheet:", error)
    throw error
  }
}

/**
 * Ensures the sheet exists, creates it if not
 */
async function ensureSheetExists(sheets) {
  try {
    // Check if the sheet exists
    const response = await sheets.spreadsheets.get({
      spreadsheetId: SPREADSHEET_ID,
    })

    const sheetExists = response.data.sheets.some((sheet) => sheet.properties.title === SHEET_NAME)

    if (!sheetExists) {
      // Create the sheet if it doesn't exist
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SPREADSHEET_ID,
        requestBody: {
          requests: [
            {
              addSheet: {
                properties: {
                  title: SHEET_NAME,
                },
              },
            },
          ],
        },
      })

      // Add headers
      await sheets.spreadsheets.values.update({
        spreadsheetId: SPREADSHEET_ID,
        range: `${SHEET_NAME}!A1:G1`,
        valueInputOption: "USER_ENTERED",
        requestBody: {
          values: [["Article #", "Publish Date", "Title", "Summary", "Tags", "Source", "URL"]],
        },
      })

      console.log(`Created sheet "${SHEET_NAME}" with headers`)
    }
  } catch (error) {
    console.error("Error ensuring sheet exists:", error)
    throw error
  }
}

/**
 * Gets existing articles from the sheet
 */
async function getExistingArticles(sheets) {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: `${SHEET_NAME}!A:G`,
    })

    const rows = response.data.values || []

    // Remove header row
    if (rows.length > 0) {
      return rows.slice(1)
    }

    return []
  } catch (error) {
    console.error("Error getting existing articles:", error)
    return []
  }
}
