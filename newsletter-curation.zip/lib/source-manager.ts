import { google } from "googleapis"
import { getGoogleAuthClient } from "./google-auth"

// Google Sheets configuration
const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID
const SOURCES_SHEET_NAME = "News Sources"

// Source type definition
export type NewsSource = {
  name: string
  url: string
  category: string
  selectors: {
    articleSelector: string
    titleSelector: string
    linkSelector: string
    dateSelector: string
    contentSelector: string
  }
}

/**
 * Fetches news sources from the Google Sheet
 */
export async function fetchNewsSources(): Promise<NewsSource[]> {
  try {
    // Get authenticated client using Workload Identity Federation
    const authClient = await getGoogleAuthClient()
    const sheets = google.sheets({ version: "v4", auth: authClient })

    // Fetch the sources from the sheet
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: `${SOURCES_SHEET_NAME}!A:F`,
    })

    const rows = response.data.values || []

    // Skip header row
    if (rows.length <= 1) {
      console.log("No sources found in the sheet")
      return []
    }

    // Parse the sources
    const sources: NewsSource[] = []
    let currentCategory = ""

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i]

      // If this is a category row (first column is filled but second is empty)
      if (row[0] && !row[1]) {
        currentCategory = row[0]
        continue
      }

      // Skip empty rows
      if (!row[1]) continue

      // Parse the source
      const name = row[1]
      const url = row[2]

      if (name && url) {
        // Determine selectors based on the website structure
        const selectors = getSelectorsForWebsite(url)

        sources.push({
          name,
          url,
          category: currentCategory,
          selectors,
        })
      }
    }

    console.log(`Fetched ${sources.length} sources from ${SOURCES_SHEET_NAME}`)
    return sources
  } catch (error) {
    console.error("Error fetching news sources:", error)
    return []
  }
}

/**
 * Determines the appropriate selectors for a given website
 * This is a simplified approach - in a real implementation, you might want to
 * have a more sophisticated mapping system or store these in the sheet
 */
function getSelectorsForWebsite(url: string): NewsSource["selectors"] {
  // Default selectors
  const defaultSelectors = {
    articleSelector: "article",
    titleSelector: "h2, h3",
    linkSelector: "a",
    dateSelector: "time",
    contentSelector: "article, .article-content, .entry-content, .post-content",
  }

  // Website-specific selectors
  if (url.includes("techcrunch.com")) {
    return {
      articleSelector: "article",
      titleSelector: "h2",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".article-content",
    }
  } else if (url.includes("theverge.com")) {
    return {
      articleSelector: "article",
      titleSelector: "h2",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".c-entry-content",
    }
  } else if (url.includes("reuters.com")) {
    return {
      articleSelector: "article, .story-card",
      titleSelector: "h3, .story-title",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".article-body",
    }
  } else if (url.includes("bbc.com") || url.includes("bbc.co.uk")) {
    return {
      articleSelector: "article, .gs-c-promo",
      titleSelector: "h3",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".article__body-content",
    }
  } else if (url.includes("cnn.com")) {
    return {
      articleSelector: "article, .card",
      titleSelector: "h3, .headline",
      linkSelector: "a",
      dateSelector: "time, .timestamp",
      contentSelector: ".article__content",
    }
  } else if (url.includes("nytimes.com")) {
    return {
      articleSelector: "article, .css-1cp3ece",
      titleSelector: "h2, .css-1j9dxys",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".css-53u6y8",
    }
  } else if (url.includes("washingtonpost.com")) {
    return {
      articleSelector: "article, .story-list-story",
      titleSelector: "h2, h3",
      linkSelector: "a",
      dateSelector: "span.wpds-c-iKQyrV",
      contentSelector: ".article-body",
    }
  } else if (url.includes("wsj.com")) {
    return {
      articleSelector: "article, .WSJTheme--story--XB4V2mLz",
      titleSelector: "h2, h3, .WSJTheme--headline--7VCzo7Ay",
      linkSelector: "a",
      dateSelector: "time, .WSJTheme--timestamp--22sfkNDv",
      contentSelector: ".article-content",
    }
  } else if (url.includes("bloomberg.com")) {
    return {
      articleSelector: "article, .story-package-module__story",
      titleSelector: "h3, .story-package-module__headline",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".body-content",
    }
  } else if (url.includes("ft.com")) {
    return {
      articleSelector: "article, .o-teaser",
      titleSelector: "h3, .o-teaser__heading",
      linkSelector: "a",
      dateSelector: "time",
      contentSelector: ".article__content-body",
    }
  }

  // Return default selectors for other websites
  return defaultSelectors
}
