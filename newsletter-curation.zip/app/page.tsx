import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-8">
      <div className="w-full max-w-5xl">
        <h1 className="text-4xl font-bold mb-8 text-center">Newsletter Curation System</h1>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Monitor the status of your newsletter curation system</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="font-medium">Last Run:</span>
                <Suspense fallback={<span>Loading...</span>}>
                  <LastRunStatus />
                </Suspense>
              </div>

              <div className="flex justify-between items-center">
                <span className="font-medium">Next Scheduled Run:</span>
                <span>Daily at 06:00 UTC</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="font-medium">Google Sheet:</span>
                <a
                  href={`https://docs.google.com/spreadsheets/d/${process.env.NEXT_PUBLIC_GOOGLE_SHEET_ID}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  View Sheet
                </a>
              </div>

              <div className="flex justify-end mt-4">
                <form action="/api/cron" method="GET">
                  <Button type="submit">Run Manually</Button>
                </form>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Information</CardTitle>
            <CardDescription>Overview of the newsletter curation system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-lg font-medium mb-2">How It Works</h3>
              <p className="text-sm text-gray-600">
                This system automatically checks for new content from configured sources daily, summarizes the content
                using AI, tags it based on relevance criteria, and adds it to a Google Sheet for editorial review.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Features</h3>
              <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                <li>Automatic content retrieval from configured sources</li>
                <li>AI-powered summarization (max 200 words)</li>
                <li>Intelligent tagging based on content analysis</li>
                <li>Automatic Google Sheet updates</li>
                <li>Daily scheduled runs</li>
                <li>Manual trigger option</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Content Sources</CardTitle>
            <CardDescription>News sources monitored by the system</CardDescription>
          </CardHeader>
          <CardContent>
            <Suspense fallback={<div>Loading sources...</div>}>
              <SourceCategories />
            </Suspense>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}

async function LastRunStatus() {
  try {
    // This would typically fetch from a database or API
    // For demo purposes, we'll return a static value
    return <span>Today at 06:00 UTC</span>
  } catch (error) {
    return <span>Unknown</span>
  }
}

async function SourceCategories() {
  try {
    // In a real implementation, this would fetch from the Google Sheet
    // For demo purposes, we'll return some static categories
    const categories = [
      "Development Banks",
      "Media - Food & Ag",
      "Media - General",
      "Research Institutions",
      "UN Agencies",
    ]

    return (
      <div className="space-y-4">
        {categories.map((category) => (
          <div key={category} className="border rounded-md p-4">
            <h3 className="font-medium mb-2">{category}</h3>
            <p className="text-sm text-gray-600">Sources from this category are checked daily for new content.</p>
          </div>
        ))}
        <p className="text-sm text-gray-500 mt-4">
          Source list is managed in the "News Sources" tab of the Google Sheet.
        </p>
      </div>
    )
  } catch (error) {
    return <div>Error loading sources</div>
  }
}
